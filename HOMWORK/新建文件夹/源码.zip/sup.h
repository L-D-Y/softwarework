#pragma once
#include <string.h>
#include<string>
#include<easyx.h>
#include<conio.h>
#define KING 1000
#define MINISTER 100
#define SUPPORT 10
#define TRIGGER 1

extern std::string Pic_Src[10];
extern std::string Txt_Src[10];
extern std::string Name[];
extern const char* const picture[];
extern const char* const txt[];
extern const char* const Data[];
class Medicine {
public:
	std::string name;
	int type;
	IMAGE *pic;
	int index;
	Medicine() {};
	Medicine(int ind);
	
};
void displayTextInEasyX(const std::string& filePath);

void MouseDrag(bool isOn,int x,int y);

void displayMedicine(Medicine m, int x, int y);

void displayTxt(std::string, int x, int y);